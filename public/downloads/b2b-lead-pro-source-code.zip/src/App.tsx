import React, { useState, useEffect } from 'react';
import { LeadItem, SearchConfig, CategoryItem } from './types';
import { DEFAULT_CATEGORIES } from './data/defaultCategories';
import { Header } from './components/Header';
import { SearchWorkflow } from './components/SearchWorkflow';
import { LeadTable } from './components/LeadTable';
import { VcfExporter } from './components/VcfExporter';
import { CategoryManagerModal } from './components/CategoryManagerModal';
import { CordovaAndroidModal } from './components/CordovaAndroidModal';
import { RecentSearches } from './components/RecentSearches';
import { hasValidPhone } from './utils/formatters';
import { 
  getRecentSearches, 
  saveRecentSearch, 
  clearRecentSearches, 
  RecentSearchItem 
} from './utils/recentSearches';

export default function App() {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [leads, setLeads] = useState<LeadItem[]>([]);
  const [categories, setCategories] = useState<CategoryItem[]>(DEFAULT_CATEGORIES);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState<boolean>(false);
  const [isCordovaModalOpen, setIsCordovaModalOpen] = useState<boolean>(false);
  const [selectedLeadsForVcf, setSelectedLeadsForVcf] = useState<LeadItem[] | null>(null);
  const [recentSearches, setRecentSearches] = useState<RecentSearchItem[]>([]);

  const [searchConfig, setSearchConfig] = useState<SearchConfig>({
    searchMode: 'manual',
    manualLocation: '',
    country: 'India',
    tag: '',
    radiusKm: 5,
    category: '',
    categories: [],
    options: {
      enrichEmails: true,
      enrichSocials: false,
      enrichIndiaMart: false,
      verifyWhatsApp: true
    }
  });

  // Load recent searches
  useEffect(() => {
    setRecentSearches(getRecentSearches());
  }, []);

  // Execute Step 1 Scraping from Commercial API
  const handleExecuteScraper = async (overrideConfig?: SearchConfig) => {
    const configToUse = overrideConfig || searchConfig;

    if (configToUse.searchMode === 'manual' && !configToUse.manualLocation.trim()) {
      alert('Please enter a target location in the search text box.');
      return;
    }
    if (configToUse.categories.length === 0) {
      alert('Please select at least one category to search.');
      return;
    }

    setIsLoading(true);

    try {
      const payload = {
        searchType: configToUse.searchMode,
        manualLocation: configToUse.manualLocation,
        country: configToUse.country,
        tag: configToUse.tag || '',
        lat: configToUse.lat,
        lng: configToUse.lng,
        radiusKm: configToUse.radiusKm,
        category: configToUse.category || configToUse.categories[0] || '',
        categories: configToUse.categories
      };

      let response = await fetch('/api/leads/scrape', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      // Auto-retry on 429 status with short backoff delay
      if (response.status === 429) {
        console.warn('Received status 429. Auto-retrying with backoff delay...');
        await new Promise((resolve) => setTimeout(resolve, 1500));
        response = await fetch('/api/leads/scrape', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      }

      if (!response.ok && response.status !== 429) {
        throw new Error(`Server returned status ${response.status}`);
      }

      const data = await response.json();
      const newLeads: LeadItem[] = data.leads || [];

      if (newLeads.length > 0) {
        setLeads(newLeads);

        // SAVE TO LOCAL STORAGE (Last 5 successful queries)
        const updatedRecent = saveRecentSearch(
          {
            manualLocation: configToUse.manualLocation,
            country: configToUse.country,
            searchMode: configToUse.searchMode,
            radiusKm: configToUse.radiusKm,
            lat: configToUse.lat,
            lng: configToUse.lng,
            categories: configToUse.categories
          },
          newLeads.length
        );
        setRecentSearches(updatedRecent);

        setActiveStep(2);
      } else {
        alert('No commercial records found for this location. Try another city or category.');
      }
    } catch (err: any) {
      console.error('Search error:', err);
      alert(`Search error: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  // Re-run search from recent searches pill
  const handleSelectRecentSearch = (item: RecentSearchItem) => {
    const restoredConfig: SearchConfig = {
      searchMode: item.searchMode,
      manualLocation: item.manualLocation,
      country: item.country,
      tag: searchConfig.tag || 'Sitori and simplgood',
      radiusKm: item.radiusKm || 5,
      lat: item.lat,
      lng: item.lng,
      category: item.categories[0] || 'Shops & Retail',
      categories: item.categories,
      options: {
        enrichEmails: true,
        enrichSocials: false,
        enrichIndiaMart: false,
        verifyWhatsApp: true
      }
    };
    setSearchConfig(restoredConfig);
    handleExecuteScraper(restoredConfig);
  };

  const handleClearSearches = () => {
    clearRecentSearches();
    setRecentSearches([]);
  };

  const validPhoneLeadsCount = leads.filter((l) => hasValidPhone(l.contactNumber)).length;

  return (
    <div className="d-flex flex-column min-vh-100 bg-light" style={{ width: '100%', overflowX: 'hidden' }}>
      
      {/* Header with B2B Lead title */}
      <Header
        activeStep={activeStep}
        setActiveStep={setActiveStep}
        leadsCount={leads.length}
        phoneCount={validPhoneLeadsCount}
        onOpenCategories={() => setIsCategoryModalOpen(true)}
        onOpenCordovaModal={() => setIsCordovaModalOpen(true)}
      />

      {/* Main Container */}
      <main className="container-xl px-2 px-sm-3 py-2 py-sm-3 flex-grow-1 d-flex flex-column" style={{ maxWidth: '100%' }}>
        
        {/* Step 1: Search Card */}
        {activeStep === 1 && (
          <SearchWorkflow
            searchConfig={searchConfig}
            setSearchConfig={setSearchConfig}
            categories={categories}
            onOpenCategories={() => setIsCategoryModalOpen(true)}
            onExecuteScraper={() => handleExecuteScraper()}
            isLoading={isLoading}
          />
        )}

        {/* Step 2: Leads & Excel */}
        {activeStep === 2 && (
          <LeadTable
            leads={leads}
            onProceedToStep3={(chosenLeads) => {
              setSelectedLeadsForVcf(chosenLeads && chosenLeads.length > 0 ? chosenLeads : null);
              setActiveStep(3);
            }}
          />
        )}

        {/* Step 3: VCF Export */}
        {activeStep === 3 && (
          <VcfExporter
            leads={selectedLeadsForVcf && selectedLeadsForVcf.length > 0 ? selectedLeadsForVcf : leads}
          />
        )}

        {/* Recent Searches placed at the bottom of the screen right above the footer */}
        <div className="mt-auto pt-2 mb-1">
          <RecentSearches
            recentSearches={recentSearches}
            onSelectSearch={handleSelectRecentSearch}
            onClearSearches={handleClearSearches}
          />
        </div>

      </main>

      {/* Clean Minimalist Artistic Footer */}
      <footer className="border-top py-3 bg-white text-muted small mt-auto" style={{ borderColor: 'var(--border-color)' }}>
        <div className="container-xl d-flex align-items-center justify-content-between flex-wrap gap-2.5">
          <div className="d-flex align-items-center gap-2">
            <div className="quad-dot-logo">
              <span className="dot-blue" />
              <span className="dot-red" />
              <span className="dot-yellow" />
              <span className="dot-green" />
            </div>
            <span className="fw-bold text-dark">B2B Lead PRO</span>
            <span className="text-muted">&bull;</span>
            <span className="text-secondary">Commercial Directory, Spreadsheet &amp; VCF Exporter</span>
          </div>
          <div className="d-flex align-items-center gap-1.5 flex-wrap">
            <span className="rounded-circle" style={{ width: '8px', height: '8px', backgroundColor: 'var(--g-blue)' }} title="Google Blue #4285F4" />
            <span className="rounded-circle" style={{ width: '8px', height: '8px', backgroundColor: 'var(--g-red)' }} title="Google Red #EA4335" />
            <span className="rounded-circle" style={{ width: '8px', height: '8px', backgroundColor: 'var(--g-yellow)' }} title="Google Yellow #FBBC05" />
            <span className="rounded-circle" style={{ width: '8px', height: '8px', backgroundColor: 'var(--g-green)' }} title="Google Green #34A853" />
          </div>
        </div>
      </footer>

      {/* Category CRUD Modal */}
      <CategoryManagerModal
        isOpen={isCategoryModalOpen}
        onClose={() => setIsCategoryModalOpen(false)}
        categories={categories}
        setCategories={setCategories}
      />

      {/* Cordova Android App Builder & Package Modal */}
      <CordovaAndroidModal
        isOpen={isCordovaModalOpen}
        onClose={() => setIsCordovaModalOpen(false)}
      />

    </div>
  );
}

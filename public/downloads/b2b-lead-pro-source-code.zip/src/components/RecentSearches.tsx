import React from 'react';
import { History, Trash2 } from 'lucide-react';
import { RecentSearchItem } from '../utils/recentSearches';

interface RecentSearchesProps {
  recentSearches: RecentSearchItem[];
  onSelectSearch: (item: RecentSearchItem) => void;
  onClearSearches: () => void;
}

export const RecentSearches: React.FC<RecentSearchesProps> = ({
  recentSearches,
  onSelectSearch,
  onClearSearches
}) => {
  if (recentSearches.length === 0) {
    return null;
  }

  // Google 4 Colors configuration
  const colorSchemes = [
    { badge: 'badge-g-blue', dot: '#4285F4' },
    { badge: 'badge-g-red', dot: '#EA4335' },
    { badge: 'badge-g-yellow', dot: '#FBBC05' },
    { badge: 'badge-g-green', dot: '#34A853' }
  ];

  return (
    <div 
      className="d-flex align-items-center gap-1.5 py-1 px-2.5 bg-white border rounded-pill shadow-xs w-100" 
      style={{ minHeight: '34px' }}
    >
      {/* Label */}
      <div className="d-flex align-items-center gap-1 text-muted fw-semibold flex-shrink-0 pe-2 border-end">
        <History size={12} className="text-primary" />
        <span style={{ fontSize: '0.7rem', letterSpacing: '0.2px' }}>Recent:</span>
      </div>

      {/* Horizontal Scrollable Chips Row */}
      <div 
        className="d-flex align-items-center gap-1.5 overflow-x-auto flex-grow-1 py-0.5" 
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {recentSearches.map((item, idx) => {
          const scheme = colorSchemes[idx % colorSchemes.length];

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectSearch(item)}
              className="btn btn-sm btn-light bg-white border py-0.5 px-2 rounded-pill d-flex align-items-center gap-1.5 flex-shrink-0 shadow-xs"
              style={{ fontSize: '0.72rem', height: '26px' }}
              title={`Re-run search: ${item.manualLocation} (${item.resultsCount} leads)`}
            >
              <span 
                className="rounded-circle flex-shrink-0"
                style={{ width: '6px', height: '6px', backgroundColor: scheme.dot }}
              />
              <span className="fw-medium text-dark text-truncate" style={{ maxWidth: '140px' }}>
                {item.manualLocation}
              </span>
              <span className={`badge ${scheme.badge} rounded-pill py-0 px-1`} style={{ fontSize: '0.62rem' }}>
                {item.resultsCount}
              </span>
            </button>
          );
        })}
      </div>

      {/* Clear Button */}
      <button
        type="button"
        onClick={onClearSearches}
        className="btn btn-sm btn-link text-decoration-none text-muted p-0 d-flex align-items-center gap-1 flex-shrink-0 ps-1"
        style={{ fontSize: '0.68rem' }}
        title="Clear recent searches"
      >
        <Trash2 size={11} />
        <span className="d-none d-sm-inline">Clear</span>
      </button>
    </div>
  );
};

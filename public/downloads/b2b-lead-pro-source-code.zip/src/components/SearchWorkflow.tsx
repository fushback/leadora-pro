import React, { useState, useEffect, useRef } from 'react';
import { 
  MapPin, 
  Navigation, 
  Search, 
  Globe, 
  Plus, 
  Loader2, 
  ArrowRight,
  Check,
  Tag,
  Sparkles
} from 'lucide-react';
import { SearchConfig, CategoryItem } from '../types';
import { COUNTRIES } from '../data/defaultCategories';

interface SuggestionItem {
  placeId?: string;
  fullText: string;
  mainText: string;
  secondaryText: string;
}

interface SearchWorkflowProps {
  searchConfig: SearchConfig;
  setSearchConfig: React.Dispatch<React.SetStateAction<SearchConfig>>;
  categories: CategoryItem[];
  onOpenCategories: () => void;
  onExecuteScraper: () => void;
  isLoading: boolean;
}

export const SearchWorkflow: React.FC<SearchWorkflowProps> = ({
  searchConfig,
  setSearchConfig,
  categories,
  onOpenCategories,
  onExecuteScraper,
  isLoading
}) => {
  const [geoStatus, setGeoStatus] = useState<string | null>(null);
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  const [suggestions, setSuggestions] = useState<SuggestionItem[]>([]);
  const [isSearchingAutocomplete, setIsSearchingAutocomplete] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Debounced Commercial Location Autocomplete
  useEffect(() => {
    const val = searchConfig.manualLocation.trim();
    if (searchConfig.searchMode !== 'manual' || val.length < 2) {
      setSuggestions([]);
      setShowDropdown(false);
      return;
    }

    const timer = setTimeout(async () => {
      try {
        setIsSearchingAutocomplete(true);
        const res = await fetch(
          `/api/places/autocomplete?input=${encodeURIComponent(val)}&country=${encodeURIComponent(searchConfig.country)}`
        );
        if (res.ok) {
          const data = await res.json();
          if (data.suggestions && data.suggestions.length > 0) {
            setSuggestions(data.suggestions);
            setShowDropdown(true);
          } else {
            setSuggestions([]);
            setShowDropdown(false);
          }
        }
      } catch (err) {
        // ignore
      } finally {
        setIsSearchingAutocomplete(false);
      }
    }, 280);

    return () => clearTimeout(timer);
  }, [searchConfig.manualLocation, searchConfig.country, searchConfig.searchMode]);

  // Click outside to close dropdown
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectSuggestion = (s: SuggestionItem) => {
    setSearchConfig((prev) => ({
      ...prev,
      manualLocation: s.fullText || `${s.mainText}, ${s.secondaryText}`
    }));
    setShowDropdown(false);
  };

  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      setGeoStatus('Geolocation not supported by browser.');
      return;
    }

    setIsDetectingLocation(true);
    setGeoStatus('Acquiring GPS coordinates...');

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        setSearchConfig((prev) => ({
          ...prev,
          lat: latitude,
          lng: longitude,
          manualLocation: `GPS: ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`
        }));
        setGeoStatus(`GPS: ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);

        try {
          const res = await fetch(`/api/geocode?lat=${latitude}&lng=${longitude}`);
          if (res.ok) {
            const data = await res.json();
            if (data.displayName) {
              const parts = data.displayName.split(',').map((s: string) => s.trim());
              const conciseLocation = parts.slice(0, 3).join(', ');
              setSearchConfig((prev) => ({
                ...prev,
                manualLocation: conciseLocation || data.displayName
              }));
              setGeoStatus(conciseLocation.slice(0, 32));
            }
          }
        } catch (e) {
          // ignore
        } finally {
          setIsDetectingLocation(false);
        }
      },
      (err) => {
        setIsDetectingLocation(false);
        setGeoStatus('GPS error. Please type location.');
      },
      { timeout: 8000 }
    );
  };

  const toggleCategorySelection = (catName: string) => {
    setSearchConfig((prev) => {
      const exists = prev.categories.includes(catName);
      let updated: string[];
      if (exists) {
        updated = prev.categories.filter((c) => c !== catName);
      } else {
        updated = [...prev.categories, catName];
      }
      return {
        ...prev,
        categories: updated,
        category: updated[0] || ''
      };
    });
  };

  const handleSelectAllCategories = () => {
    const allNames = categories.map((c) => c.name);
    setSearchConfig((prev) => ({
      ...prev,
      categories: allNames,
      category: allNames[0] || ''
    }));
  };

  const handleClearCategories = () => {
    setSearchConfig((prev) => ({
      ...prev,
      categories: [],
      category: ''
    }));
  };

  return (
    <div className="g-card p-3 p-sm-4 mb-3 mb-md-4 position-relative">
      
      {/* Top Header: Mode Switcher & Real-time Live Badge */}
      <div className="d-flex align-items-center justify-content-between mb-3 pb-2.5 border-bottom flex-wrap gap-2">
        <div className="p-1 bg-light rounded-pill border d-inline-flex" style={{ gap: '2px' }}>
          <button
            type="button"
            onClick={() => setSearchConfig((p) => ({ ...p, searchMode: 'manual' }))}
            className={`btn btn-sm rounded-pill px-3 py-1 fw-semibold ${
              searchConfig.searchMode === 'manual'
                ? 'bg-white text-primary shadow-sm border'
                : 'text-muted border-0 bg-transparent'
            }`}
            style={{ fontSize: '0.8rem', transition: 'all 0.18s ease' }}
          >
            <MapPin size={13} className="me-1.5 text-primary inline" />
            <span>City &amp; Area Search</span>
          </button>
          
          <button
            type="button"
            onClick={() => setSearchConfig((p) => ({ ...p, searchMode: 'proximity' }))}
            className={`btn btn-sm rounded-pill px-3 py-1 fw-semibold ${
              searchConfig.searchMode === 'proximity'
                ? 'bg-white text-success shadow-sm border'
                : 'text-muted border-0 bg-transparent'
            }`}
            style={{ fontSize: '0.8rem', transition: 'all 0.18s ease' }}
          >
            <Navigation size={13} className="me-1.5 text-success inline" />
            <span>Near Me (GPS)</span>
          </button>
        </div>

        {/* Live commercial database badge with Green dot */}
        <span className="badge badge-g-green py-1 px-2.5 rounded-pill ms-auto ms-sm-0 shadow-xs">
          <span className="rounded-circle d-inline-block me-1.5" style={{ width: '6px', height: '6px', backgroundColor: 'var(--g-green)' }} />
          <span>Real-time Places API Online</span>
        </span>
      </div>

      {/* Input Controls */}
      {searchConfig.searchMode === 'manual' ? (
        <div className="row g-2 g-sm-3 mb-3" ref={dropdownRef}>
          {/* Location input with live autocomplete */}
          <div className="col-12 col-md-8 position-relative">
            <label className="form-label text-muted small fw-semibold d-flex justify-content-between mb-1" style={{ fontSize: '0.78rem' }}>
              <span>Target Commercial Location</span>
              {isSearchingAutocomplete && (
                <span className="text-primary small d-flex align-items-center gap-1" style={{ fontSize: '0.7rem' }}>
                  <Loader2 size={11} className="animate-spin" />
                  <span>Searching...</span>
                </span>
              )}
            </label>

            <div className="input-group">
              <span className="input-group-text bg-white border-end-0 text-muted px-2.5">
                <MapPin size={16} className="text-primary" />
              </span>
              <input
                type="text"
                value={searchConfig.manualLocation}
                onChange={(e) => setSearchConfig((p) => ({ ...p, manualLocation: e.target.value }))}
                onFocus={() => {
                  if (suggestions.length > 0) setShowDropdown(true);
                }}
                placeholder="e.g. Indiranagar Bangalore, Connaught Place Delhi, MG Marg Gangtok"
                className="form-control border-start-0 ps-1"
                style={{ fontSize: '0.875rem' }}
              />
            </div>

            {/* Dropdown Suggestions */}
            {showDropdown && suggestions.length > 0 && (
              <div
                className="position-absolute start-0 end-0 mt-1 bg-white border rounded shadow-lg overflow-hidden"
                style={{ zIndex: 1050, maxHeight: '220px', overflowY: 'auto' }}
              >
                <div className="px-3 py-1.5 bg-light border-bottom text-muted small fw-semibold text-uppercase text-start" style={{ fontSize: '0.65rem' }}>
                  Suggested Commercial Hubs
                </div>
                {suggestions.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelectSuggestion(item)}
                    className="dropdown-search-item"
                  >
                    <MapPin size={14} className="text-primary flex-shrink-0 mt-1 me-2" />
                    <div style={{ flex: 1, minWidth: 0, textAlign: 'left' }}>
                      <div className="fw-semibold text-dark small text-start text-truncate">
                        {item.mainText}
                      </div>
                      <div className="text-muted text-start text-truncate" style={{ fontSize: '0.72rem' }}>
                        {item.secondaryText}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Country Selector */}
          <div className="col-12 col-md-4">
            <label className="form-label text-muted small fw-semibold mb-1" style={{ fontSize: '0.78rem' }}>
              Country
            </label>
            <div className="input-group">
              <span className="input-group-text bg-white border-end-0 text-muted px-2.5">
                <Globe size={16} className="text-primary" />
              </span>
              <select
                value={searchConfig.country}
                onChange={(e) => setSearchConfig((p) => ({ ...p, country: e.target.value }))}
                className="form-select border-start-0 ps-1"
                style={{ fontSize: '0.875rem' }}
              >
                {COUNTRIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      ) : (
        /* Proximity GPS Controls */
        <div className="p-3 bg-light rounded-3 border mb-3">
          <div className="row g-2 align-items-center">
            <div className="col-12 col-sm-auto">
              <button
                type="button"
                onClick={handleDetectLocation}
                disabled={isDetectingLocation}
                className="btn btn-g-blue btn-center d-flex align-items-center justify-content-center gap-1.5 btn-sm px-3 py-2 w-100 w-sm-auto rounded-pill"
              >
                {isDetectingLocation ? <Loader2 size={13} className="animate-spin" /> : <Navigation size={13} />}
                <span>{isDetectingLocation ? 'Detecting GPS...' : 'Detect GPS Location'}</span>
              </button>
            </div>

            {geoStatus && (
              <div className="col-12 col-sm text-muted small font-monospace text-truncate">
                {geoStatus}
              </div>
            )}

            <div className="col-12 col-sm-auto ms-sm-auto d-flex align-items-center gap-2">
              <span className="small text-muted fw-semibold" style={{ fontSize: '0.78rem' }}>Search Radius:</span>
              <span className="badge badge-g-yellow px-2 py-1 rounded-pill fw-bold" style={{ fontSize: '0.75rem' }}>
                {searchConfig.radiusKm} km
              </span>
              <input
                type="range"
                min="1"
                max="50"
                step="1"
                value={searchConfig.radiusKm}
                onChange={(e) => setSearchConfig((p) => ({ ...p, radiusKm: Number(e.target.value) }))}
                className="form-range"
                style={{ width: '110px' }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Dedicated Artistic "Tag" Input Field Box with 4-Color Touch */}
      <div 
        className="p-3 rounded-3 border mb-3 position-relative" 
        style={{ 
          backgroundColor: '#FFFFFF',
          borderColor: '#E2E8F0',
          boxShadow: '0 2px 8px rgba(251, 188, 5, 0.08)' 
        }}
      >
        <div className="d-flex align-items-center justify-content-between mb-1.5 flex-wrap gap-1">
          <label htmlFor="tag-input-field" className="form-label text-dark fw-bold small mb-0 d-flex align-items-center gap-1.5" style={{ fontSize: '0.82rem' }}>
            <Tag size={15} style={{ color: 'var(--g-yellow-text)' }} />
            <span>Tag (Field name &quot;Tag&quot;)</span>
          </label>
          <span className="badge badge-g-yellow py-0.5 px-2 rounded-pill font-monospace fw-bold" style={{ fontSize: '0.7rem' }}>
            Spreadsheet &bull; VCF Note &bull; Contact Name
          </span>
        </div>

        <div className="input-group">
          <span className="input-group-text bg-light border-end-0 text-muted px-2.5">
            <Tag size={15} className="text-warning" />
          </span>
          <input
            id="tag-input-field"
            type="text"
            value={searchConfig.tag || ''}
            onChange={(e) => setSearchConfig((p) => ({ ...p, tag: e.target.value }))}
            placeholder="Enter Tag (optional)"
            className="form-control border-start-0 ps-1"
            style={{ fontSize: '0.875rem' }}
          />
        </div>

        <div className="d-flex align-items-center justify-content-between mt-2 flex-wrap gap-2 text-muted" style={{ fontSize: '0.72rem' }}>
          <span>
            Spreadsheet: <strong>Tag</strong> column &bull; Last Name: <strong>[Category] - [Tag]</strong>
          </span>
          <span>
            Note: <strong>[Tag]</strong> &bull; Tag: <strong>[Tag]</strong>
          </span>
        </div>
      </div>

      {/* Categories Multi-Select Chips - Playful interactive bounce */}
      <div className="mb-3 mb-md-4">
        <div className="d-flex align-items-center justify-content-between mb-2 flex-wrap gap-2">
          <label className="text-muted small fw-bold text-uppercase" style={{ fontSize: '0.7rem', letterSpacing: '0.5px' }}>
            Target Categories ({searchConfig.categories.length} selected)
          </label>
          <div className="d-flex align-items-center gap-2">
            <button
              type="button"
              onClick={handleSelectAllCategories}
              className="btn btn-sm btn-link text-decoration-none text-primary p-0 small"
              style={{ fontSize: '0.75rem' }}
            >
              Select All
            </button>
            <span className="text-muted" style={{ fontSize: '0.7rem' }}>&bull;</span>
            <button
              type="button"
              onClick={handleClearCategories}
              className="btn btn-sm btn-link text-decoration-none text-muted p-0 small"
              style={{ fontSize: '0.75rem' }}
            >
              Clear
            </button>
            <span className="text-muted" style={{ fontSize: '0.7rem' }}>&bull;</span>
            <button
              type="button"
              onClick={onOpenCategories}
              className="btn btn-sm btn-link text-decoration-none text-secondary p-0 d-flex align-items-center gap-1 small"
              style={{ fontSize: '0.75rem' }}
            >
              <Plus size={13} />
              <span>Manage</span>
            </button>
          </div>
        </div>

        <div className="d-flex flex-wrap gap-2 pt-1">
          {categories.map((cat) => {
            const isSelected = searchConfig.categories.includes(cat.name);
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => toggleCategorySelection(cat.name)}
                className={`category-chip ${isSelected ? 'active' : ''}`}
              >
                <span>{cat.name}</span>
                {isSelected && <Check size={12} className="stroke-[3]" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Submit Action with Blue #4285F4 & Playful Hover */}
      <button
        type="button"
        onClick={onExecuteScraper}
        disabled={isLoading}
        className="btn btn-g-blue btn-center w-100 py-2.5 fw-semibold d-flex align-items-center justify-content-center gap-2 rounded-3 shadow-sm"
        style={{ fontSize: '0.92rem' }}
      >
        {isLoading ? (
          <>
            <Loader2 size={17} className="animate-spin" />
            <span>Searching Live Database &amp; Applying Tag...</span>
          </>
        ) : (
          <>
            <Search size={17} />
            <span>Search B2B Leads</span>
            <ArrowRight size={17} />
          </>
        )}
      </button>
    </div>
  );
};

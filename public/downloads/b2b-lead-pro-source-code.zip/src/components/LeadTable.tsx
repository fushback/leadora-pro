import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  FileSpreadsheet, 
  ExternalLink, 
  Phone, 
  Mail, 
  MessageSquare, 
  Search, 
  ArrowRight,
  Loader2,
  CheckSquare,
  X,
  Tag
} from 'lucide-react';
import { LeadItem } from '../types';
import { generateExcelWorkbook } from '../utils/excelGenerator';
import { CategoryDistributionChart } from './CategoryDistributionChart';

interface LeadTableProps {
  leads: LeadItem[];
  onProceedToStep3: (selectedLeads?: LeadItem[]) => void;
}

export const LeadTable: React.FC<LeadTableProps> = ({ leads, onProceedToStep3 }) => {
  const [selectedCategoryTab, setSelectedCategoryTab] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isExporting, setIsExporting] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const selectAllCheckboxRef = useRef<HTMLInputElement>(null);

  // Group leads by category for tabs
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    leads.forEach((l) => {
      const cat = l.category || 'General';
      counts[cat] = (counts[cat] || 0) + 1;
    });
    return counts;
  }, [leads]);

  const uniqueCategories = Object.keys(categoryCounts);

  // Filter leads based on active category tab & search query
  const filteredLeads = useMemo(() => {
    return leads.filter((item) => {
      const matchesCategory =
        selectedCategoryTab === 'all' || item.category === selectedCategoryTab;

      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        item.businessName.toLowerCase().includes(q) ||
        item.address.toLowerCase().includes(q) ||
        item.location.toLowerCase().includes(q) ||
        item.contactNumber.includes(q) ||
        item.email.toLowerCase().includes(q);

      return matchesCategory && matchesSearch;
    });
  }, [leads, selectedCategoryTab, searchQuery]);

  // Selection state helpers
  const visibleSelectedCount = useMemo(() => {
    return filteredLeads.filter(l => selectedIds.has(l.id)).length;
  }, [filteredLeads, selectedIds]);

  const isAllVisibleSelected = filteredLeads.length > 0 && visibleSelectedCount === filteredLeads.length;
  const isSomeVisibleSelected = visibleSelectedCount > 0 && !isAllVisibleSelected;

  // Sync indeterminate state on the header checkbox
  useEffect(() => {
    if (selectAllCheckboxRef.current) {
      selectAllCheckboxRef.current.indeterminate = isSomeVisibleSelected;
    }
  }, [isSomeVisibleSelected]);

  // Toggle single lead selection
  const handleToggleRow = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  // Toggle select all visible
  const handleToggleSelectAll = () => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (isAllVisibleSelected) {
        filteredLeads.forEach(l => next.delete(l.id));
      } else {
        filteredLeads.forEach(l => next.add(l.id));
      }
      return next;
    });
  };

  // Select all leads in database
  const handleSelectAllInDatabase = () => {
    setSelectedIds(new Set(leads.map(l => l.id)));
  };

  // Clear all selections
  const handleClearSelection = () => {
    setSelectedIds(new Set());
  };

  // Compute which leads to export: if any selected, export selected; else export all
  const leadsToExport = useMemo(() => {
    if (selectedIds.size === 0) return leads;
    return leads.filter(l => selectedIds.has(l.id));
  }, [leads, selectedIds]);

  // Dual-Path Excel Download for chosen contacts
  const handleDownloadExcel = async () => {
    if (leadsToExport.length === 0) return;
    setIsExporting(true);

    try {
      const suffix = selectedIds.size > 0 ? `Selected_${leadsToExport.length}` : 'All';
      const filename = `B2B_Leads_${suffix}_${new Date().toISOString().slice(0, 10)}.xlsx`;
      generateExcelWorkbook(leadsToExport, filename);
    } catch (clientErr: any) {
      console.warn('Client Excel generation fallback to server API:', clientErr);
      try {
        const response = await fetch('/api/export/excel', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ leads: leadsToExport })
        });
        if (response.ok) {
          const blob = await response.blob();
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          const suffix = selectedIds.size > 0 ? `Selected_${leadsToExport.length}` : 'All';
          a.download = `B2B_Leads_${suffix}_${new Date().toISOString().slice(0, 10)}.xlsx`;
          document.body.appendChild(a);
          a.click();
          setTimeout(() => {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
          }, 2000);
        } else {
          alert('Could not export file.');
        }
      } catch (serverErr: any) {
        alert(`Export error: ${serverErr.message}`);
      }
    } finally {
      setTimeout(() => setIsExporting(false), 500);
    }
  };

  // Handler for proceeding to VCF
  const handleProceedToVcf = () => {
    onProceedToStep3(leadsToExport);
  };

  return (
    <div className="g-card p-3 p-sm-4 mb-3 mb-md-4">
      {/* Top Header */}
      <div className="d-flex align-items-sm-center justify-content-between flex-column flex-sm-row gap-2.5 pb-2.5 mb-3 border-bottom">
        <div>
          <h2 className="fs-5 fw-bold text-dark mb-0">Leads Database &amp; Spreadsheet</h2>
          <small className="text-muted">
            {leads.length} verified commercial records organized into categorized sheets
          </small>
        </div>

        <div className="d-flex align-items-center gap-2 flex-wrap w-100 w-sm-auto">
          {/* Download Spreadsheet Button in Google Green #34A853 */}
          <button
            type="button"
            onClick={handleDownloadExcel}
            disabled={leads.length === 0 || isExporting}
            className="btn btn-g-green btn-sm d-flex align-items-center justify-content-center gap-1.5 px-3 py-2 flex-fill flex-sm-grow-0 rounded-pill shadow-sm"
            title={selectedIds.size > 0 ? `Export ${selectedIds.size} selected leads` : `Export all ${leads.length} leads`}
          >
            {isExporting ? <Loader2 size={14} className="animate-spin" /> : <FileSpreadsheet size={14} />}
            <span>
              {selectedIds.size > 0 
                ? `Export Spreadsheet (${selectedIds.size} selected)` 
                : 'Download Spreadsheet'}
            </span>
          </button>

          {/* Proceed to VCF in Google Blue #4285F4 */}
          <button
            type="button"
            onClick={handleProceedToVcf}
            disabled={leads.length === 0}
            className={`btn btn-sm d-flex align-items-center justify-content-center gap-1.5 px-3 py-2 flex-fill flex-sm-grow-0 rounded-pill shadow-sm ${
              selectedIds.size > 0 ? 'btn-g-blue' : 'btn-outline-g-blue'
            }`}
            title={selectedIds.size > 0 ? `Proceed to VCF with ${selectedIds.size} selected leads` : 'Proceed to VCF'}
          >
            <span>
              {selectedIds.size > 0 
                ? `Proceed to VCF (${selectedIds.size})` 
                : 'Proceed to VCF'}
            </span>
            <ArrowRight size={13} />
          </button>
        </div>
      </div>

      {/* Recharts Lead Category Distribution Summary */}
      <CategoryDistributionChart
        leads={leads}
        selectedCategory={selectedCategoryTab}
        onSelectCategory={(cat) => setSelectedCategoryTab(cat)}
      />

      {/* Multi-Select Floating Action Alert Bar */}
      {selectedIds.size > 0 && (
        <div className="alert alert-primary py-2 px-3 mb-2.5 d-flex align-items-center justify-content-between flex-wrap gap-2 rounded-3 border-0 bg-primary-subtle text-primary-emphasis shadow-xs">
          <div className="d-flex align-items-center gap-2 flex-wrap">
            <CheckSquare size={16} className="text-primary flex-shrink-0" />
            <span className="fw-semibold small" style={{ fontSize: '0.8rem' }}>
              <strong>{selectedIds.size}</strong> of {leads.length} contacts selected
            </span>
            {selectedIds.size < leads.length && (
              <button
                type="button"
                onClick={handleSelectAllInDatabase}
                className="btn btn-sm btn-link p-0 text-decoration-underline text-primary fw-semibold"
                style={{ fontSize: '0.75rem' }}
              >
                Select all {leads.length} leads
              </button>
            )}
          </div>
          <div className="d-flex align-items-center gap-1.5 ms-auto">
            <button
              type="button"
              onClick={handleClearSelection}
              className="btn btn-outline-secondary btn-sm py-0.5 px-2.5 bg-white rounded-pill d-flex align-items-center gap-1"
              style={{ fontSize: '0.72rem' }}
            >
              <X size={12} />
              <span>Clear selection</span>
            </button>
          </div>
        </div>
      )}

      {/* Category Tabs & Quick Search */}
      <div className="d-flex align-items-center justify-content-between flex-column flex-sm-row gap-2 mb-3">
        {/* Flat Category Tabs with Playful Active State */}
        <div 
          className="d-flex align-items-center gap-1.5 pb-1 w-100 overflow-auto"
          style={{ WebkitOverflowScrolling: 'touch', scrollbarWidth: 'none' }}
        >
          <button
            type="button"
            onClick={() => setSelectedCategoryTab('all')}
            className={`btn btn-sm rounded-pill px-3 py-1 text-nowrap flex-shrink-0 fw-semibold ${
              selectedCategoryTab === 'all'
                ? 'btn-g-blue text-white shadow-xs'
                : 'btn-light border text-secondary'
            }`}
            style={{ fontSize: '0.78rem' }}
          >
            All Leads ({leads.length})
          </button>

          {uniqueCategories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategoryTab(cat)}
              className={`btn btn-sm rounded-pill px-2.5 px-sm-3 py-1 text-nowrap flex-shrink-0 d-flex align-items-center gap-1.5 fw-semibold ${
                selectedCategoryTab === cat
                  ? 'btn-g-blue text-white shadow-xs'
                  : 'btn-light border text-secondary'
              }`}
              style={{ fontSize: '0.78rem' }}
            >
              <span>{cat}</span>
              <span
                className={`badge rounded-pill ${
                  selectedCategoryTab === cat ? 'bg-white text-primary' : 'bg-light text-dark border'
                }`}
                style={{ fontSize: '0.62rem' }}
              >
                {categoryCounts[cat]}
              </span>
            </button>
          ))}
        </div>

        {/* Search Field */}
        <div className="input-group input-group-sm w-100 w-sm-auto flex-shrink-0" style={{ maxWidth: '240px' }}>
          <span className="input-group-text bg-white border-end-0 text-muted px-2.5">
            <Search size={14} className="text-primary" />
          </span>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter leads..."
            className="form-control border-start-0 ps-1"
            style={{ fontSize: '0.8rem' }}
          />
        </div>
      </div>

      {/* Table with responsive horizontal touch scrolling */}
      <div 
        className="table-responsive border rounded bg-white" 
        style={{ maxHeight: '520px', WebkitOverflowScrolling: 'touch', width: '100%', maxWidth: '100%' }}
      >
        <table className="table table-hover table-striped align-middle mb-0" style={{ fontSize: '0.8rem', width: '100%' }}>
          <thead className="table-light sticky-top text-uppercase text-muted" style={{ fontSize: '0.7rem', letterSpacing: '0.4px', zIndex: 5 }}>
            <tr>
              {/* Multi-Select Header Checkbox */}
              <th className="py-2 px-2 text-center" style={{ width: '40px' }}>
                <input
                  ref={selectAllCheckboxRef}
                  type="checkbox"
                  className="form-check-input"
                  checked={isAllVisibleSelected}
                  onChange={handleToggleSelectAll}
                  style={{ cursor: 'pointer' }}
                  title="Select / Deselect all visible leads"
                />
              </th>
              <th className="py-2 px-2" style={{ minWidth: '34px' }}>#</th>
              <th className="py-2 px-2.5" style={{ minWidth: '170px' }}>Business Name</th>
              <th className="py-2 px-2.5" style={{ minWidth: '200px' }}>Address</th>
              <th className="py-2 px-2.5" style={{ minWidth: '120px' }}>Location</th>
              <th className="py-2 px-2.5" style={{ minWidth: '90px' }}>Map View</th>
              <th className="py-2 px-2.5" style={{ minWidth: '130px' }}>Contact Number</th>
              <th className="py-2 px-2.5" style={{ minWidth: '130px' }}>Email</th>
              <th className="py-2 px-2.5" style={{ minWidth: '110px' }}>WhatsApp</th>
              <th className="py-2 px-2.5" style={{ minWidth: '120px' }}>Tag</th>
            </tr>
          </thead>
          <tbody>
            {filteredLeads.length === 0 ? (
              <tr>
                <td colSpan={10} className="py-5 text-center text-muted">
                  No records match your filter.
                </td>
              </tr>
            ) : (
              filteredLeads.map((item, idx) => {
                const isSelected = selectedIds.has(item.id);
                return (
                  <tr 
                    key={item.id || idx}
                    className={isSelected ? 'table-primary' : ''}
                    style={{ cursor: 'pointer' }}
                    onClick={() => handleToggleRow(item.id)}
                  >
                    {/* Row Checkbox */}
                    <td 
                      className="px-2 text-center" 
                      onClick={(e) => e.stopPropagation()}
                    >
                      <input
                        type="checkbox"
                        className="form-check-input"
                        checked={isSelected}
                        onChange={() => handleToggleRow(item.id)}
                        style={{ cursor: 'pointer' }}
                        title="Select lead"
                      />
                    </td>

                    <td className="px-2 text-muted font-monospace" style={{ fontSize: '0.72rem' }}>
                      {idx + 1}
                    </td>

                    {/* Business Name */}
                    <td className="px-2.5">
                      <div className="fw-semibold text-dark">{item.businessName}</div>
                      <small className="text-muted d-block" style={{ fontSize: '0.68rem' }}>
                        {item.category}
                      </small>
                    </td>

                    {/* Address */}
                    <td className="px-2.5 text-truncate" style={{ maxWidth: '240px' }} title={item.address}>
                      {item.address}
                    </td>

                    {/* Location */}
                    <td className="px-2.5 text-nowrap text-secondary">
                      {item.location}
                    </td>

                    {/* Map Link */}
                    <td className="px-2.5 text-nowrap" onClick={(e) => e.stopPropagation()}>
                      {item.googleMapLocation ? (
                        <a
                          href={item.googleMapLocation}
                          target="_blank"
                          rel="noreferrer"
                          className="btn btn-outline-g-blue btn-sm py-0.5 px-2 d-inline-flex align-items-center gap-1"
                          style={{ fontSize: '0.7rem' }}
                        >
                          <span>View Map</span>
                          <ExternalLink size={10} />
                        </a>
                      ) : (
                        <span className="text-muted">—</span>
                      )}
                    </td>

                    {/* Contact Number */}
                    <td className="px-2.5 text-nowrap font-monospace fw-semibold text-dark" onClick={(e) => e.stopPropagation()}>
                      {item.contactNumber ? (
                        <a href={`tel:${item.contactNumber}`} className="text-decoration-none text-dark d-flex align-items-center gap-1">
                          <Phone size={11} className="text-primary" />
                          <span>{item.contactNumber}</span>
                        </a>
                      ) : (
                        <span className="text-muted fw-normal" style={{ fontSize: '0.72rem' }}>Not Listed</span>
                      )}
                    </td>

                    {/* Email */}
                    <td className="px-2.5 text-nowrap font-monospace text-secondary" style={{ fontSize: '0.72rem' }} onClick={(e) => e.stopPropagation()}>
                      {item.email ? (
                        <a href={`mailto:${item.email}`} className="text-decoration-none text-secondary d-flex align-items-center gap-1">
                          <Mail size={11} className="text-muted" />
                          <span>{item.email}</span>
                        </a>
                      ) : (
                        <span className="text-muted">—</span>
                      )}
                    </td>

                    {/* WhatsApp */}
                    <td className="px-2.5 text-nowrap" onClick={(e) => e.stopPropagation()}>
                      {item.whatsappNo ? (
                        <a
                          href={`https://wa.me/${item.whatsappNo.replace(/\D/g, '')}`}
                          target="_blank"
                          rel="noreferrer"
                          className="badge badge-g-green text-decoration-none d-inline-flex align-items-center gap-1 py-1 px-2 font-monospace"
                          style={{ fontSize: '0.7rem' }}
                        >
                          <MessageSquare size={10} className="text-success" />
                          <span>{item.whatsappNo}</span>
                        </a>
                      ) : (
                        <span className="text-muted">—</span>
                      )}
                    </td>

                    {/* Tag Field in Table */}
                    <td className="px-2.5 text-nowrap">
                      <span className="badge badge-g-yellow font-monospace px-2 py-1 rounded-pill" style={{ fontSize: '0.68rem' }}>
                        <Tag size={10} className="me-1 inline" style={{ color: 'var(--g-yellow-text)' }} />
                        {item.tag || item.note || 'Sitori and simplgood'}
                      </span>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

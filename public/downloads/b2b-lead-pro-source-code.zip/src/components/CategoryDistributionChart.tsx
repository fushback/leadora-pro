import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { LeadItem } from '../types';
import { BarChart3, PieChart as PieIcon, ChevronDown, ChevronUp, Layers } from 'lucide-react';

interface CategoryDistributionChartProps {
  leads: LeadItem[];
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
}

// Google 4 Colors & clean palette for chart slices
const GOOGLE_PALETTE = [
  '#4285F4', // Google Blue
  '#34A853', // Google Green
  '#EA4335', // Google Red
  '#FBBC05', // Google Yellow
  '#9334E6', // Purple
  '#12B5CB', // Cyan
  '#FA7B17', // Orange
  '#E52592'  // Pink
];

export const CategoryDistributionChart: React.FC<CategoryDistributionChartProps> = ({
  leads,
  selectedCategory,
  onSelectCategory
}) => {
  const [chartType, setChartType] = useState<'bar' | 'pie'>('bar');
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Group leads by category and compute counts + percentages
  const chartData = useMemo(() => {
    if (!leads || leads.length === 0) return [];

    const counts: Record<string, number> = {};
    leads.forEach((l) => {
      const cat = l.category && l.category.trim() ? l.category.trim() : 'Uncategorized';
      counts[cat] = (counts[cat] || 0) + 1;
    });

    return Object.entries(counts)
      .map(([name, count], index) => ({
        name,
        count,
        percentage: Number(((count / leads.length) * 100).toFixed(1)),
        color: GOOGLE_PALETTE[index % GOOGLE_PALETTE.length]
      }))
      .sort((a, b) => b.count - a.count);
  }, [leads]);

  if (leads.length === 0 || chartData.length === 0) {
    return null;
  }

  return (
    <div className="bg-light rounded-3 border p-2.5 p-sm-3 mb-3">
      {/* Header bar */}
      <div className="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-2">
        <div className="d-flex align-items-center gap-1.5">
          <Layers size={15} className="text-primary" />
          <span className="fw-bold text-dark fs-6" style={{ fontSize: '0.85rem' }}>
            Category Distribution
          </span>
          <span className="badge badge-g-blue rounded-pill" style={{ fontSize: '0.65rem' }}>
            {chartData.length} {chartData.length === 1 ? 'Category' : 'Categories'}
          </span>
          <span className="text-muted d-none d-sm-inline" style={{ fontSize: '0.72rem' }}>
            (Click any category to filter table)
          </span>
        </div>

        <div className="d-flex align-items-center gap-1.5 ms-auto">
          {/* Chart Type Toggle */}
          <div className="btn-group btn-group-sm bg-white rounded p-0.5 border" role="group">
            <button
              type="button"
              onClick={() => setChartType('bar')}
              className={`btn btn-sm py-0.5 px-2 d-flex align-items-center gap-1 border-0 ${
                chartType === 'bar' ? 'bg-primary text-white shadow-xs' : 'text-muted'
              }`}
              style={{ fontSize: '0.7rem' }}
              title="Bar Chart"
            >
              <BarChart3 size={11} />
              <span className="d-none d-md-inline">Bar</span>
            </button>
            <button
              type="button"
              onClick={() => setChartType('pie')}
              className={`btn btn-sm py-0.5 px-2 d-flex align-items-center gap-1 border-0 ${
                chartType === 'pie' ? 'bg-primary text-white shadow-xs' : 'text-muted'
              }`}
              style={{ fontSize: '0.7rem' }}
              title="Donut Chart"
            >
              <PieIcon size={11} />
              <span className="d-none d-md-inline">Donut</span>
            </button>
          </div>

          {/* Collapse/Expand Toggle */}
          <button
            type="button"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="btn btn-sm btn-outline-secondary py-0.5 px-1.5 d-flex align-items-center"
            style={{ fontSize: '0.7rem' }}
            title={isCollapsed ? 'Show Chart' : 'Hide Chart'}
          >
            {isCollapsed ? <ChevronDown size={13} /> : <ChevronUp size={13} />}
          </button>
        </div>
      </div>

      {/* Chart Body */}
      {!isCollapsed && (
        <div className="row g-2 align-items-center">
          {/* Chart Canvas */}
          <div className="col-12 col-md-7" style={{ height: '170px' }}>
            <ResponsiveContainer width="100%" height="100%">
              {chartType === 'bar' ? (
                <BarChart
                  data={chartData}
                  layout="vertical"
                  margin={{ top: 5, right: 25, left: 10, bottom: 5 }}
                >
                  <XAxis type="number" hide />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={90}
                    tick={{ fontSize: 11, fill: '#3C4043' }}
                    tickFormatter={(val) => (val.length > 12 ? `${val.substring(0, 11)}…` : val)}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-white border rounded shadow-sm p-2" style={{ fontSize: '0.75rem' }}>
                            <div className="fw-bold text-dark">{data.name}</div>
                            <div className="text-muted d-flex align-items-center gap-2 mt-0.5">
                              <span><strong>{data.count}</strong> leads</span>
                              <span>•</span>
                              <span><strong>{data.percentage}%</strong> of total</span>
                            </div>
                            <div className="text-primary mt-1" style={{ fontSize: '0.65rem' }}>
                              Click to filter table
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar
                    dataKey="count"
                    radius={[0, 4, 4, 0]}
                    onClick={(data) => {
                      if (data && data.name) {
                        onSelectCategory(selectedCategory === data.name ? 'all' : data.name);
                      }
                    }}
                    cursor="pointer"
                  >
                    {chartData.map((entry, idx) => (
                      <Cell
                        key={`cell-${idx}`}
                        fill={entry.color}
                        opacity={selectedCategory === 'all' || selectedCategory === entry.name ? 1 : 0.4}
                      />
                    ))}
                  </Bar>
                </BarChart>
              ) : (
                <PieChart margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-white border rounded shadow-sm p-2" style={{ fontSize: '0.75rem' }}>
                            <div className="fw-bold text-dark">{data.name}</div>
                            <div className="text-muted d-flex align-items-center gap-2 mt-0.5">
                              <span><strong>{data.count}</strong> leads</span>
                              <span>•</span>
                              <span><strong>{data.percentage}%</strong></span>
                            </div>
                            <div className="text-primary mt-1" style={{ fontSize: '0.65rem' }}>
                              Click to filter table
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Pie
                    data={chartData}
                    dataKey="count"
                    nameKey="name"
                    innerRadius={38}
                    outerRadius={65}
                    paddingAngle={3}
                    onClick={(data) => {
                      if (data && data.name) {
                        onSelectCategory(selectedCategory === data.name ? 'all' : data.name);
                      }
                    }}
                    cursor="pointer"
                  >
                    {chartData.map((entry, idx) => (
                      <Cell
                        key={`pie-cell-${idx}`}
                        fill={entry.color}
                        opacity={selectedCategory === 'all' || selectedCategory === entry.name ? 1 : 0.35}
                      />
                    ))}
                  </Pie>
                </PieChart>
              )}
            </ResponsiveContainer>
          </div>

          {/* Interactive Legend & Percentage Badges */}
          <div className="col-12 col-md-5">
            <div className="d-flex flex-wrap gap-1.5 align-items-center max-h-100" style={{ maxHeight: '160px', overflowY: 'auto' }}>
              {chartData.map((item) => {
                const isSelected = selectedCategory === item.name;
                return (
                  <button
                    key={item.name}
                    type="button"
                    onClick={() => onSelectCategory(isSelected ? 'all' : item.name)}
                    className={`btn btn-sm d-flex align-items-center justify-content-between gap-2 py-1 px-2 rounded-2 text-start transition-all ${
                      isSelected
                        ? 'bg-white border-primary shadow-xs'
                        : 'bg-white border text-secondary hover-bg-light'
                    }`}
                    style={{
                      fontSize: '0.72rem',
                      flex: '1 1 calc(50% - 4px)',
                      minWidth: '130px',
                      borderLeft: `3px solid ${item.color}`
                    }}
                    title={`Filter by ${item.name}`}
                  >
                    <span className="text-truncate fw-medium text-dark">{item.name}</span>
                    <span className="badge bg-light text-dark border rounded-pill flex-shrink-0" style={{ fontSize: '0.65rem' }}>
                      {item.count} ({item.percentage}%)
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

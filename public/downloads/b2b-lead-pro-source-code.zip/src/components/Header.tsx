import React from 'react';
import { Search, FileSpreadsheet, Contact, SlidersHorizontal, Smartphone, Code2, Sparkles } from 'lucide-react';

interface HeaderProps {
  activeStep: number;
  setActiveStep: (step: number) => void;
  leadsCount: number;
  phoneCount: number;
  onOpenCategories: () => void;
  onOpenCordovaModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeStep,
  setActiveStep,
  leadsCount,
  phoneCount,
  onOpenCategories,
  onOpenCordovaModal
}) => {
  return (
    <header className="bg-white border-bottom sticky-top" style={{ zIndex: 1020, boxShadow: '0 2px 8px rgba(15, 23, 42, 0.04)' }}>
      {/* Playful Animated 4-Color Gradient Shimmer Line */}
      <div className="quad-gradient-line" />

      <div className="container-xl py-2">
        <div className="d-flex align-items-center justify-content-between gap-2 flex-wrap flex-sm-nowrap">
          
          {/* Brand Logo with Playful Quad Dots */}
          <div 
            className="d-flex align-items-center gap-2 cursor-pointer flex-shrink-0"
            onClick={() => setActiveStep(1)}
            style={{ cursor: 'pointer' }}
            title="B2B Lead Pro Home"
          >
            <div className="quad-dot-logo" title="Playful 4-Color Mark">
              <span className="dot-blue" />
              <span className="dot-red" />
              <span className="dot-yellow" />
              <span className="dot-green" />
            </div>

            <div className="d-flex align-items-center gap-1.5">
              <span className="fw-bold text-dark fs-6 lh-1" style={{ letterSpacing: '-0.3px', whiteSpace: 'nowrap' }}>
                B2B Lead
              </span>
              <span className="badge badge-g-blue py-0.5 px-1.5 rounded-pill fw-bold" style={{ fontSize: '0.62rem' }}>
                PRO
              </span>
            </div>
          </div>

          {/* Artistic Minimalist Step Switcher */}
          <div className="d-flex align-items-center p-1 bg-light rounded-pill border" style={{ gap: '3px' }}>
            {/* Step 1: Search */}
            <button
              type="button"
              onClick={() => setActiveStep(1)}
              className={`step-nav-pill ${activeStep === 1 ? 'active-step-1' : ''}`}
              title="Step 1: Search B2B Leads"
            >
              <Search size={13} className={activeStep === 1 ? 'text-primary' : 'text-muted'} />
              <span>Search</span>
            </button>

            {/* Step 2: Leads */}
            <button
              type="button"
              onClick={() => setActiveStep(2)}
              className={`step-nav-pill ${activeStep === 2 ? 'active-step-2' : ''}`}
              title="Step 2: Commercial Leads & Spreadsheet"
            >
              <FileSpreadsheet size={13} className={activeStep === 2 ? 'text-success' : 'text-muted'} />
              <span>Leads</span>
              {leadsCount > 0 && (
                <span
                  className="badge rounded-pill py-0 px-1.5 fw-bold"
                  style={{
                    fontSize: '0.62rem',
                    backgroundColor: activeStep === 2 ? 'var(--g-green)' : '#CBD5E1',
                    color: activeStep === 2 ? '#FFFFFF' : '#334155'
                  }}
                >
                  {leadsCount}
                </span>
              )}
            </button>

            {/* Step 3: VCF Export */}
            <button
              type="button"
              onClick={() => setActiveStep(3)}
              className={`step-nav-pill ${activeStep === 3 ? 'active-step-3' : ''}`}
              title="Step 3: VCF Contact Card Exporter"
            >
              <Contact size={13} className={activeStep === 3 ? 'text-danger' : 'text-muted'} />
              <span>VCF</span>
              {phoneCount > 0 && (
                <span
                  className="badge rounded-pill py-0 px-1.5 fw-bold"
                  style={{
                    fontSize: '0.62rem',
                    backgroundColor: activeStep === 3 ? 'var(--g-red)' : '#CBD5E1',
                    color: activeStep === 3 ? '#FFFFFF' : '#334155'
                  }}
                >
                  {phoneCount}
                </span>
              )}
            </button>
          </div>

          {/* Quick Action Buttons */}
          <div className="d-flex align-items-center gap-1.5 flex-nowrap ms-auto ms-sm-0">
            {/* Categories */}
            <button
              type="button"
              onClick={onOpenCategories}
              className="btn btn-sm btn-outline-secondary d-flex align-items-center gap-1 py-1 px-2.5 rounded-pill bg-white"
              style={{ fontSize: '0.75rem', height: '32px' }}
              title="Manage Categories"
            >
              <SlidersHorizontal size={13} className="text-secondary" />
              <span className="d-none d-md-inline">Categories</span>
            </button>

            {/* Android Cordova App */}
            <button
              type="button"
              onClick={onOpenCordovaModal}
              className="btn btn-sm btn-outline-g-green d-flex align-items-center gap-1 py-1 px-2.5 rounded-pill bg-white"
              style={{ fontSize: '0.75rem', height: '32px' }}
              title="Build & Download Android App (.apk)"
            >
              <Smartphone size={13} className="text-success" />
              <span className="d-none d-sm-inline">Android App</span>
            </button>

            {/* Source Code ZIP */}
            <a
              href="/downloads/b2b-lead-pro-source-code.zip"
              download="b2b-lead-pro-source-code.zip"
              className="btn btn-sm btn-outline-g-blue d-flex align-items-center gap-1 py-1 px-2.5 rounded-pill bg-white text-decoration-none"
              style={{ fontSize: '0.75rem', height: '32px' }}
              title="Download clean project source code"
            >
              <Code2 size={13} className="text-primary" />
              <span className="d-none d-md-inline">Source Code</span>
            </a>
          </div>

        </div>
      </div>
    </header>
  );
};

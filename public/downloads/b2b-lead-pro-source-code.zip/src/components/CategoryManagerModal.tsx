import React, { useState } from 'react';
import { X, Plus, Trash2, Edit2, Check, RefreshCcw, Layers } from 'lucide-react';
import { CategoryItem } from '../types';
import { DEFAULT_CATEGORIES } from '../data/defaultCategories';

interface CategoryManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: CategoryItem[];
  setCategories: React.Dispatch<React.SetStateAction<CategoryItem[]>>;
}

export const CategoryManagerModal: React.FC<CategoryManagerModalProps> = ({
  isOpen,
  onClose,
  categories,
  setCategories
}) => {
  const [newCatName, setNewCatName] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  if (!isOpen) return null;

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    const newCategory: CategoryItem = {
      id: newCatName.toLowerCase().trim().replace(/\s+/g, '_') + '_' + Date.now(),
      name: newCatName.trim(),
      description: `${newCatName.trim()} establishments`,
      icon: 'Store',
      color: '#4285F4',
      isCustom: true
    };

    setCategories((prev) => [...prev, newCategory]);
    setNewCatName('');
  };

  const handleDeleteCategory = (id: string) => {
    if (categories.length <= 1) {
      alert('You must retain at least one category.');
      return;
    }
    setCategories((prev) => prev.filter((c) => c.id !== id));
  };

  const handleStartEdit = (cat: CategoryItem) => {
    setEditingId(cat.id);
    setEditName(cat.name);
  };

  const handleSaveEdit = (id: string) => {
    if (!editName.trim()) return;
    setCategories((prev) =>
      prev.map((c) => (c.id === id ? { ...c, name: editName.trim() } : c))
    );
    setEditingId(null);
  };

  const handleRestoreDefaults = () => {
    if (confirm('Restore default categories?')) {
      setCategories(DEFAULT_CATEGORIES);
    }
  };

  return (
    <div
      className="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center p-3"
      style={{ backgroundColor: 'rgba(32, 33, 36, 0.4)', zIndex: 1060 }}
    >
      <div className="bg-white border rounded-3 shadow w-100" style={{ maxWidth: '480px', maxHeight: '85vh', display: 'flex', flexDirection: 'column' }}>
        
        {/* Header */}
        <div className="p-3 border-bottom d-flex align-items-center justify-content-between">
          <div className="d-flex align-items-center gap-2">
            <Layers size={18} className="text-primary" />
            <h6 className="mb-0 fw-bold text-dark">Manage Business Categories</h6>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="btn btn-sm btn-link text-muted p-1"
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-3 overflow-auto flex-grow-1">
          {/* Add form */}
          <form onSubmit={handleAddCategory} className="d-flex gap-2 mb-3">
            <input
              type="text"
              placeholder="e.g. Pharmacy, Clinic, Hardware"
              value={newCatName}
              onChange={(e) => setNewCatName(e.target.value)}
              className="form-control form-control-sm"
            />
            <button
              type="submit"
              disabled={!newCatName.trim()}
              className="btn btn-g-blue btn-sm px-3 text-nowrap"
            >
              <Plus size={14} className="me-1" />
              <span>Add</span>
            </button>
          </form>

          <div className="d-flex align-items-center justify-content-between mb-2">
            <small className="text-muted fw-semibold text-uppercase" style={{ fontSize: '0.7rem' }}>
              Categories ({categories.length})
            </small>
            <button
              type="button"
              onClick={handleRestoreDefaults}
              className="btn btn-link p-0 small text-decoration-none text-muted d-flex align-items-center gap-1"
              style={{ fontSize: '0.75rem' }}
            >
              <RefreshCcw size={11} />
              <span>Reset Defaults</span>
            </button>
          </div>

          <div className="d-flex flex-column gap-1" style={{ maxHeight: '280px', overflowY: 'auto' }}>
            {categories.map((cat) => {
              const isEditing = editingId === cat.id;

              return (
                <div
                  key={cat.id}
                  className="p-2 rounded border bg-light d-flex align-items-center justify-content-between"
                  style={{ fontSize: '0.8rem' }}
                >
                  {isEditing ? (
                    <div className="d-flex align-items-center gap-2 flex-grow-1 me-2">
                      <input
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="form-control form-control-sm py-0"
                      />
                      <button
                        type="button"
                        onClick={() => handleSaveEdit(cat.id)}
                        className="btn btn-sm btn-success py-0 px-2"
                      >
                        <Check size={12} />
                      </button>
                    </div>
                  ) : (
                    <span className="fw-medium text-dark">{cat.name}</span>
                  )}

                  <div className="d-flex align-items-center gap-1">
                    {!isEditing && (
                      <button
                        type="button"
                        onClick={() => handleStartEdit(cat)}
                        className="btn btn-sm btn-link text-muted p-1"
                      >
                        <Edit2 size={13} />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleDeleteCategory(cat.id)}
                      className="btn btn-sm btn-link text-danger p-1"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-top d-flex justify-content-end">
          <button
            type="button"
            onClick={onClose}
            className="btn btn-sm btn-light border px-3"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};

import * as XLSX from 'xlsx';
import { LeadItem } from '../types';

/**
 * Robust cross-browser blob download trigger that works reliably in all browsers and sandboxed iframes.
 */
function triggerBlobDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.style.display = 'none';
  a.href = url;
  a.setAttribute('download', filename);
  a.setAttribute('target', '_blank');
  document.body.appendChild(a);

  // Trigger click
  a.click();

  // Clean up with delay so download starts before revoke
  setTimeout(() => {
    try {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
      URL.revokeObjectURL(url);
    } catch (e) {
      // ignore
    }
  }, 3000);
}

/**
 * Builds and downloads a multi-sheet Excel (.xlsx) workbook strictly matching required columns:
 * 1. Business Name
 * 2. Address
 * 3. Location
 * 4. Category
 * 5. Tag (applied across Excel, VCF Note & Name)
 * 6. Google Map Location (clickable hyperlink)
 * 7. Contact Number (authentic number from Google Maps)
 * 8. Email
 * 9. WhatsApp No
 * 10. Website
 * 11. Note
 */
export function generateExcelWorkbook(leads: LeadItem[], filename = 'B2B_Leads_Database.xlsx'): void {
  if (!leads || leads.length === 0) {
    throw new Error('No leads available to export.');
  }

  const workbook = XLSX.utils.book_new();

  // Group leads by category
  const categoriesMap: Record<string, LeadItem[]> = {};

  leads.forEach((lead) => {
    const cat = lead.category?.trim() || 'General';
    if (!categoriesMap[cat]) {
      categoriesMap[cat] = [];
    }
    categoriesMap[cat].push(lead);
  });

  const categoryNames = Object.keys(categoriesMap);

  // 1. All Leads Master Sheet
  appendSheetForLeads(workbook, 'All Leads', leads);

  // 2. Separate Sheet for each category found
  categoryNames.forEach((catName) => {
    const sanitizedSheetName = catName
      .replace(/[\\/?*[\]:]/g, ' ')
      .trim()
      .slice(0, 31) || 'Sheet';

    if (sanitizedSheetName !== 'All Leads') {
      appendSheetForLeads(workbook, sanitizedSheetName, categoriesMap[catName]);
    }
  });

  // Write workbook as array buffer
  const excelBuffer = XLSX.write(workbook, {
    bookType: 'xlsx',
    type: 'array'
  });

  const blob = new Blob([excelBuffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8'
  });

  triggerBlobDownload(blob, filename);
}

function appendSheetForLeads(workbook: XLSX.WorkBook, sheetName: string, items: LeadItem[]) {
  const headers = [
    'Business Name',
    'Address',
    'Location',
    'Category',
    'Tag', // New Tag column applied in Excel
    'Google Map Location',
    'Contact Number',
    'Email',
    'WhatsApp No',
    'Website',
    'Note'
  ];

  const rows: any[][] = [headers];

  items.forEach((item) => {
    const mapUrl = item.googleMapLocation || `https://maps.google.com/?q=${encodeURIComponent(item.businessName + ' ' + item.address)}`;
    const tag = item.tag || item.note || '';

    rows.push([
      item.businessName || '',
      item.address || '',
      item.location || '',
      item.category || '',
      tag,
      mapUrl,
      item.contactNumber || '',
      item.email || '',
      item.whatsappNo || '',
      item.website || '',
      item.note || tag
    ]);
  });

  const worksheet = XLSX.utils.aoa_to_sheet(rows);

  // Column widths
  worksheet['!cols'] = [
    { wch: 32 }, // Business Name
    { wch: 42 }, // Address
    { wch: 24 }, // Location
    { wch: 22 }, // Category
    { wch: 22 }, // Tag
    { wch: 40 }, // Google Map Location
    { wch: 18 }, // Contact Number
    { wch: 26 }, // Email
    { wch: 18 }, // WhatsApp No
    { wch: 28 }, // Website
    { wch: 24 }  // Note
  ];

  // Make Map links clickable in Excel
  const range = XLSX.utils.decode_range(worksheet['!ref'] || 'A1:K1');
  for (let R = 1; R <= range.e.r; ++R) {
    const cellAddress = XLSX.utils.encode_cell({ r: R, c: 5 }); // Column F is Google Map Location
    const cell = worksheet[cellAddress];
    if (cell && cell.v && typeof cell.v === 'string' && cell.v.startsWith('http')) {
      cell.l = { Target: cell.v, Tooltip: 'View on Google Maps' };
    }
  }

  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
}

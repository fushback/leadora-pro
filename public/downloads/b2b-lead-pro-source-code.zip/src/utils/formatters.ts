/**
 * Formats a phone number into standard WhatsApp format with country code.
 * Defaults to +91 for 10-digit Indian numbers if no country code provided.
 */
export function formatWhatsAppNumber(phone: string, country = 'India'): string {
  if (!phone) return '';
  
  // Extract all digits and any leading '+'
  const cleaned = phone.trim();
  const digitsOnly = cleaned.replace(/\D/g, '');
  
  if (!digitsOnly) return '';

  // If already starts with '+' or international prefix
  if (cleaned.startsWith('+')) {
    return '+' + digitsOnly;
  }

  // Handle Indian mobile numbers (10 digits starting with 6, 7, 8, 9)
  if (digitsOnly.length === 10 && (country.toLowerCase() === 'india' || country.toLowerCase() === 'in')) {
    return '+91' + digitsOnly;
  }

  // If 11 digits starting with 0 (e.g. 098320...) in India
  if (digitsOnly.length === 11 && digitsOnly.startsWith('0') && country.toLowerCase() === 'india') {
    return '+91' + digitsOnly.slice(1);
  }

  // If 12 digits starting with 91
  if (digitsOnly.length === 12 && digitsOnly.startsWith('91')) {
    return '+' + digitsOnly;
  }

  // If 11 digits starting with 1 (USA/Canada)
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    return '+' + digitsOnly;
  }

  return digitsOnly.length >= 7 ? '+' + digitsOnly : '';
}

/**
 * Validates whether a lead has an actual callable phone number
 */
export function hasValidPhone(phone?: string): boolean {
  if (!phone) return false;
  const digits = phone.replace(/\D/g, '');
  return digits.length >= 7 && digits.length <= 15;
}

/**
 * Extracts a 6-digit Indian PIN code or general 5-6 digit postal code from address string
 */
export function extractPincode(address: string): string {
  if (!address) return '';
  // Match 6 digits surrounded by word boundaries or space (standard PIN in India: 734001, 110001 etc.)
  const pinMatch = address.match(/\b([1-9][0-9]{5})\b/);
  if (pinMatch) return pinMatch[1];

  // Fallback to 5-digit US zip code
  const zipMatch = address.match(/\b([0-9]{5})\b/);
  if (zipMatch) return zipMatch[1];

  return '';
}

/**
 * Safely slugifies a string for file names
 */
export function slugify(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '_')
    .replace(/[^\w\-]+/g, '')
    .replace(/\-\-+/g, '_')
    .slice(0, 50);
}

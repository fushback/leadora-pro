export interface SocialProfiles {
  facebook?: string;
  instagram?: string;
  indiamart?: string;
  tradeindia?: string;
  justdial?: string;
  linkedin?: string;
}

export interface LeadItem {
  id: string;
  businessName: string;
  category: string;
  tag?: string; // Applied to Excel & VCF note and [Category] - [Tag]
  address: string;
  location: string; // Short location: Road/Street name, Area/Town/City, State/District
  googleMapLocation: string; // Hyperlink
  contactNumber: string;
  email: string;
  whatsappNo: string;
  pincode: string;
  website: string;
  socialProfiles: SocialProfiles;
  rating?: number;
  reviewsCount?: number;
  verified?: boolean;
  note: string; // [Tag] into note section
  scrapedAt: string;
  source?: string;
}

export type SearchMode = 'manual' | 'proximity';

export interface SearchConfig {
  searchMode: SearchMode;
  manualLocation: string; // e.g. "Sevoke Road, Siliguri" or "MG Marg, Gangtok, Sikkim"
  country: string; // default "India"
  tag: string; // Field name "Tag" applied in Excel and VCF note & name
  lat?: number;
  lng?: number;
  radiusKm: number; // in kilometers
  category: string;
  categories: string[];
  options: {
    enrichEmails: boolean;
    enrichSocials: boolean;
    enrichIndiaMart: boolean;
    verifyWhatsApp: boolean;
  };
}

export interface CategoryItem {
  id: string;
  name: string;
  description: string;
  icon?: string;
  color?: string;
  isCustom?: boolean;
}

export interface AgentLog {
  id: string;
  timestamp: string;
  agent: 'Step 1: Scraper' | 'Step 2: Aggregator' | 'Step 3: VCF Generator';
  message: string;
  status: 'info' | 'success' | 'warning' | 'error' | 'in_progress';
  dataCount?: number;
}
